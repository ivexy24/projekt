<template>
  <the-navbar></the-navbar>
  <the-section></the-section>
  <grey-background></grey-background>
  <sobre-section></sobre-section>
  <section-between></section-between>
  <grey-background></grey-background>
  <team-section></team-section>
  <agenda-section></agenda-section>
  <grey-background></grey-background>
  <section-form></section-form>
  <the-footer></the-footer>
</template>

<script>
import AgendaSection from "./components/AgendaSection.vue";
import TheNavbar from "./components/TheNavbar.vue";
import TheSection from "./components/TheSection.vue";
import GreyBackground from "./components/GreyBackground.vue";
import SobreSection from "./components/SobreSection.vue";
import SectionBetween from "./components/SectionBetween.vue";
import TeamSection from "./components/TeamSection.vue";
import SectionForm from "./components/SectionForm";
import TheFooter from "./components/TheFooter.vue";
export default {
  components: {
    TheNavbar,
    TheSection,
    AgendaSection,
    GreyBackground,
    SobreSection,
    SectionBetween,
    TeamSection,
    SectionForm,
    TheFooter,
  },
};
</script>

<style>
@import url("https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;500;600;700;900&display=swap");
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html {
  font-family: Raleway, system-ui, -apple-system, Segoe UI, Roboto, Ubuntu,
    Cantarell, Noto Sans, sans-serif, Helvetica, Arial, Apple Color Emoji,
    Segoe UI Emoji, Segoe UI Symbol;
}
html,
body {
  max-width: 100%;
  overflow-x: hidden;
}
</style>