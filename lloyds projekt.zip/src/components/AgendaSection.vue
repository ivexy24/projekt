<template>
  <section>
    <div class="title"><h1>Agenda</h1></div>
    <div class="text">
      Fique por dentro da programação do evento. <br />
      Observação: a ordem pode sofrer alterações.
    </div>
    <ul>
      <li>
        <div class="icon-cont">
          <div class="circle icon">
            <img src="../images/member1.jpg" alt="" />
          </div>
        </div>
        <div class="timeline">
          <div class="clock-text">
            <p>08:00 - 08:50</p>
          </div>
          <div class="tl-title">
            <h4>Credenciamento</h4>
          </div>
          <div class="tl-desc">
            O Credenciamento no evento é obrigatório e não ocorre além do
            horário estipulado.
          </div>
          <div class="tl-duration">
            <p>50min</p>
          </div>
        </div>
      </li>
      <li>
        <div class="icon-cont">
          <div class="circle icon">
            <img src="../images/member2.jpg" alt="" />
          </div>
        </div>
        <div class="timeline">
          <div class="clock-text">
            <p>08:50 - 09:00</p>
          </div>
          <div class="tl-title">
            <h4>Abertura</h4>
          </div>
          <div class="tl-desc">
            <p>
              Boas vindas da organização e agradecimentos aos patrocinadores.
            </p>
          </div>
          <div class="tl-duration">
            <p>10min</p>
          </div>
        </div>
      </li>
      <li>
        <div class="icon-cont">
          <div class="circle icon">
            <img src="../images/member3.jpg" alt="" />
          </div>
        </div>
        <div class="timeline">
          <div class="clock-text">
            <p>09:00 - 10:00</p>
          </div>
          <div class="tl-title">
            <h4>Utilizando Kotlin no desenvolvimento back-end</h4>
          </div>
          <div class="tl-desc">
            <p>
              Kotlin é uma das linguagens de programação oficiais para o
              desenvolvimento Android, mas também é uma linguagem
              multiplataforma, assim vem ganhando cada vez mais espaço em
              diversos cenários, além do próprio desenvolvimento mobile. Nesta
              apresentação, os participantes poderão acompanhar as principais
              características que tornam esta linguagem poderosa e divertida,
              bem como exemplos práticos da sua aplicabilidade no back-end do
              iFood.
            </p>
          </div>
          <div class="tl-duration">
            <p>60min</p>
          </div>
          <div class="link">
            <i class="fas fa-mic"></i>
            <a href="#leo">Rodolpho Couto</a>
          </div>
        </div>
      </li>
      <li>
        <div class="icon-cont">
          <div class="circle icon">
            <img src="../images/member5.jpg" alt="" />
          </div>
        </div>
        <div class="timeline">
          <div class="clock-text">
            <p>10:10 - 11:10</p>
          </div>
          <div class="tl-title">
            <h4>Compartilhando experiências sobre DevOps nas empresas</h4>
          </div>
          <div class="tl-desc">
            DevOps é um termo derivado da junção das palavras "desenvolvimento"
            e "operações", designando um conjunto de práticas de engenharia de
            software para melhor integração das equipes de desenvolvedores com
            as equipes de operação (infraestrutura e administração de sistemas).
            Nesta palestra, os participantes poderão acompanhar experiências
            vivenciadas pelo palestrante ao longo de suas passagens por diversas
            empresas de renome, atuando com administração de sistemas e DevOps.
          </div>
          <div class="tl-duration">
            <p>60min</p>
          </div>
          <div class="link">
            <i class="fas fa-mic"></i>
            <a href="#leo">Hugo Branquinho</a>
          </div>
        </div>
      </li>
      <li>
        <div class="icon-cont">
          <div class="circle icon">
            <img src="../images/member1.jpg" alt="" />
          </div>
        </div>
        <div class="timeline">
          <div class="clock-text">
            <p>11:20 - 12:20</p>
          </div>
          <div class="tl-title">
            <h4>
              Construção de um algoritmo de inteligência artificial em Python
            </h4>
          </div>
          <div class="tl-desc">
            <p>
              Embora a área de inteligência artificial exista desde a segunda
              guerra mundial, recentemente tem se tornado muito mais popular,
              principalmente graças ao desenvolvimento de máquinas potentes o
              bastante para comportar seus algoritmos. Nesta palestra, os
              participantes poderão compreender o que é Inteligência Artificial
              e quais suas principais áreas, enquanto acompanham a construção de
              um algoritmo de classificação com machine learning, utilizando-se
              a linguagem de programação Python.
            </p>
          </div>
          <div class="tl-duration">
            <p>60min</p>
          </div>
          <div class="link">
            <i class="fas fa-mic"></i>
            <a href="#leo">Leticia Pedroso</a>
          </div>
        </div>
      </li>
      <li>
        <div class="icon-cont">
          <div class="circle icon">
            <img src="../images/member1.jpg" alt="" />
          </div>
        </div>
        <div class="timeline">
          <div class="clock-text">
            <p>12:20 - 13:50</p>
          </div>
          <div class="tl-title">
            <h4>Almoço</h4>
          </div>
          <div class="tl-desc">
            <p>
              O intervalo para almoço é livre, cada participante pode escolher
              onde fazer sua refeição.
            </p>
          </div>
          <div class="tl-duration">
            <p>1h30min</p>
          </div>
        </div>
      </li>

      <li>
        <div class="icon-cont">
          <div class="circle icon">
            <img src="../images/member1.jpg" alt="" />
          </div>
        </div>
        <div class="timeline">
          <div class="clock-text">
            <p>14:00 - 15:00</p>
          </div>
          <div class="tl-title">
            <h4>Introdução à programação funcional com Clojure</h4>
          </div>
          <div class="tl-desc">
            <p>
              Clojure é uma linguagem dinâmica de uso geral, combinando a
              acessibilidade e o desenvolvimento interativo de uma linguagem
              interpretada com uma infraestrutura eficiente e robusta de uma
              linguagem compilada, focada em programação multithread, seguindo
              como paradigma predominantemente a programação funcional. Nesta
              apresentação, os participantes poderão conhecer os conceitos
              básicos de Clojure e de programação funcional, enquanto descobrem
              como ambos são excelentes opções para qualquer tipo de projeto.
            </p>
          </div>
          <div class="tl-duration">
            <p>60min</p>
          </div>
          <div class="link">
            <i class="fas fa-mic"></i>
            <a href="#leo">Bruno Schaefer</a>
          </div>
        </div>
      </li>
      <li>
        <div class="icon-cont">
          <div class="circle icon">
            <img src="../images/member1.jpg" alt="" />
          </div>
        </div>
        <div class="timeline">
          <div class="clock-text">
            <p>15:10 - 16:10</p>
          </div>
          <div class="tl-title">
            <h4>Desenvolvimento de um aplicativo nativo com React Native</h4>
          </div>
          <div class="tl-desc">
            <p>
              React Native é uma biblioteca JavaScript criada pelo Facebook. É
              usada para desenvolver aplicativos para os sistemas Android e iOS
              de forma nativa. Nesta palestra, os participantes poderão ver e
              avaliar as vantagens do ecossistema JavaScript no desenvolvimento
              de um aplicativo nativo utilizando React Native.
            </p>
          </div>
          <div class="tl-duration">
            <p>60min</p>
          </div>
          <div class="link">
            <a href="#leo">Leonardo Bittencourt</a>
          </div>
        </div>
      </li>
      <li>
        <div class="icon-cont">
          <div class="circle icon">
            <img src="../images/member1.jpg" alt="" />
          </div>
        </div>
        <div class="timeline">
          <div class="clock-text">
            <p>16:10 - 16:35</p>
          </div>
          <div class="tl-title">
            <h4>Coffee Break</h4>
          </div>
          <div class="tl-desc">
            <p>
              Um intervalo rápido para tomarmos um café no evento e voltarmos
              com tudo.
            </p>
          </div>
          <div class="tl-duration">
            <p>60min</p>
          </div>
        </div>
      </li>
      <li>
        <div class="icon-cont">
          <div class="circle icon">
            <img src="../images/member1.jpg" alt="" />
          </div>
        </div>
        <div class="timeline">
          <div class="clock-text">
            <p>16:40 - 17:40</p>
          </div>
          <div class="tl-title">
            <h4>Nest.js: um framework Node.js poderoso e progressivo</h4>
          </div>
          <div class="tl-desc">
            <p>
              O Nest.js é um poderoso framework open source baseado no Node.js,
              Express e TypeScript. Fortemente inspirado no Angular 2+, o
              Nest.js se propõe a ser uma alternativa para criação de aplicações
              progressivas e extremamente escaláveis de maneira muito simples,
              oferecendo inclusive integrações eficientes com outros frameworks
              e bibliotecas tradicionais no mundo Node.js, como Mongoose,
              Sequelize, TypeORM, Swagger e Prisma. Nesta palestra, os
              participantes poderão ver seu poder e facilidade ao acompanhar a
              criação de um projeto Node.js utilizando o Nest.js.
            </p>
          </div>
          <div class="tl-duration">
            <p>60min</p>
          </div>
          <div class="link">
            <i class="fas fa-mic"></i>
            <a href="#leo">Cleber Campomori</a>
          </div>
        </div>
      </li>
      <li>
        <div class="icon-cont">
          <div class="circle icon">
            <img src="../images/member1.jpg" alt="" />
          </div>
        </div>
        <div class="timeline">
          <div class="clock-text">
            <p>17:40</p>
          </div>
          <div class="tl-title">
            <h4>Encerramento</h4>
          </div>
          <div class="tl-desc">
            <p>
              Agradecimentos aos participantes, patrocinadores e recados finais
              do evento. criação de um projeto Node.js utilizando o Nest.js.
            </p>
          </div>
        </div>
      </li>
    </ul>
  </section>
</template>

<script>
export default {};
</script>

<style scoped>
section {
  height: 100%;
  width: 100%;
  position: relative;
  padding: 5em calc(5em + 3vw);
}
.title {
  text-align: center;
  margin: 4rem 0 1rem 0;
  color: red;
  font-weight: 900;
  font-size: 1.4rem;
}
.text {
  text-align: center;
  margin-bottom: 2rem;
  font-weight: bold;
}
ul {
  background: #f9fafb;
  border: 1px solid #e3e8eb;
  box-shadow: 0 8px 20px rgba(198, 209, 214, 0.12);
  list-style: none;
  margin: 3rem 0 0;
  padding: 0 0 0 2rem;
}
li {
  position: relative;
  display: flex;
  border-left: 1px solid #fc4d52;
  margin-left: 2em;
  padding: 20px 2em 32px 0;
}
li:not(:last-child) {
  border-bottom: 1px solid rgba(92, 90, 85, 0.1);
}

.circle,
.icon {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: -2rem;
}
img {
  border-radius: 50%;
  height: 4rem;
  width: 4rem;
  border: 2px solid rgba(159, 2, 7, 0.4);
}
.timeline {
  margin-left: 2rem;
}
.clock-text {
  color: rgb(163, 11, 11);
  margin-top: 1rem;
}
.tl-title {
  color: red;
  font-size: 1.5rem;
}
.tl-desc {
  font-size: 1.1rem;
  line-height: 0.7cm;
  color: #36434a;
  font-weight: bolder;
}
.tl-duration {
  position: absolute;
  right: 2rem;
  top: 1rem;
  padding: 0.3rem 0.5rem;
  background: rgb(201, 51, 51);
  color: #fff;
  font-size: 0.7rem;
  border-radius: 5px;
}
.link a {
  text-decoration: none;
  font-size: 0.8rem;
  color: #c21e23;
  font-weight: bold;
}
@media screen and (max-width: 768px) {
  section {
    padding: 1rem;
    height: 100%;
  }
  ul li {
    width: 100%;
    margin-left: 0;
  }
  ul {
    padding: 0;
    width: 100%;
  }
  .clock-text {
    font-size: 0.8rem;
  }
  .tl-title {
    font-size: 1.1rem;
  }
  .tl-desc {
    font-size: 0.9rem;
  }
  .circle,
  .icon {
    margin-left: 0;
  }
  ul li:last-child {
    margin-bottom: 1rem;
  }
}
</style>