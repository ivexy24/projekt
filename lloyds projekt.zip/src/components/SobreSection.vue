<template>
  <section>
    <div class="container">
      <div class="text">
        <h2 id="sobre">O que é <span class="br">Fatec Dev Day?</span></h2>
        <p>
          Realizado no segundo semestre de cada ano, o
          <span>Fatec Dev Day </span>é um evento dedicado a discutir o que há de
          <span>mais recente</span> nas tendências e tecnologias para o
          desenvolvimento de <span>sistemas</span> e de
          <span>aplicativos</span>. Trata-se de um dia inteiro de palestras e
          atrações, em que os estudantes e profissionais de Taquaritinga e
          região não apenas se atualizam sobre as novidades em TI, mas também
          podem <span>compartilhar conhecimento</span> e fazer contato com
          grandes profissionais do setor.
        </p>
        <p class="invs">
          A<span> edição 2016</span> do <span>Fatec Dev Day</span> inaugurou
          esta tradição anual com palestras relacionadas a Angular 2 e
          TypeScript, aplicações Web modernas com Laravel, arquitetura de
          microserviços em Java, Bots e Machine Learning, Internet das Coisas
          (IoT), introdução ao Docker, mobile e Progressive Web Apps (PWA). Na
          <span>edição 2017</span>, os participantes puderem acompanhar talks
          realacionadas a assuntos como deploy de aplicações usando Docker,
          implementação de pick up line generators com JavaScript, Inteligência
          Artificial e reconhecimento óptico com PHP, migração do Java para o
          Node, operações HTTP com Python, uso do React, além de uma sessão
          especial de live coding, em que os participantes puderam acompanhar,
          ao vivo, o desenvolvimento de um mesmo aplicativo em versões para
          Android e para iOS. Já a <span>edição 2018</span> abordou temas como
          desenvolvimento de chat bots utilizando IBM Watson, automação de
          testes de software com Selenium WebDriver, maximixação de resultados
          através de UX, desenvolvimento de aplicativos móveis com Flutter,
          conceitos de machine learning, criação de aplicações móveis nativas em
          Vue.js com NativeScript-Vue, aplicações REST em Go com Gin e GORM e
          aplicações Web com ASP.NET Core.
        </p>
        <p>
          A <span>edição 2019</span> do <span>Fatec Dev Day </span>aconteceu em
          <span>9 de novembro</span> na Faculdade de Tecnologia de Taquaritinga
          e, assim como nas edições anteriores, contou com diversos
          profissionais renomados em suas áreas, apresentando palestras
          relacionadas a Kotlin no desenvolvimento back-end, experiências
          práticas sobre DevOps, construção de algoritimo de Inteligência
          Artificial em Python, conceitos de programação funcional com Clojure,
          criação de aplicações móveis nativas com React Native e construção de
          um projeto Node.js utilizando o framework progressivo Nest.js.
        </p>
        <p>
          Se você esteve conosco, não se esqueça de contribuir oferecendo sua
          opinião sobre o evento, para nos ajudar a construir um
          <span>Fatec Dev Day</span>
          cada vez melhor para a edição de 2020!
        </p>
      </div>
      <div class="imgs">
        <div class="first-photo"></div>
        <div class="second-photo"></div>
        <div class="third-photo"></div>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style scoped>
section {
  height: 65vh;
  width: 100%;
  box-shadow: 0px 5px 8px rgba(0, 0, 0, 0.5);
  overflow: hidden;
}
.container {
  display: flex;
  width: 100%;
  justify-content: space-between;
}
.text {
  width: 70%;
  text-align: center;
  margin-top: 4rem;
  margin-left: 10rem;
}
span {
  color: rgb(224, 4, 4);
}
h2 {
  font-size: 2rem;
  margin-bottom: 1rem;
  font-weight: 900;
  color: rgb(247, 41, 41);
}
p {
  font-size: 1.1rem;
  color: rgba(60, 76, 83, 0.97);
  font-weight: 600;
}
p:not(:last-child) {
  margin-bottom: 1rem;
}
.imgs {
  display: flex;
  flex-direction: column;
}
.first-photo,
.second-photo,
.third-photo {
  width: 17rem;
  height: 13.5rem;
  object-fit: cover;
}
.first-photo {
  background: url("https://d33wubrfki0l68.cloudfront.net/8561c0c0b64df5bf88161d1c3d6ef529436d4c01/3cddd/_nuxt/img/c4e847d.jpg");
  background-size: cover;
}
.second-photo {
  background: url("https://d33wubrfki0l68.cloudfront.net/b5d94c9a95376d39485b5150f5f541b9cb450bbf/52a10/_nuxt/img/775b56d.jpg");
  background-size: cover;
}
.third-photo {
  background: url("https://d33wubrfki0l68.cloudfront.net/03ab6d1b57b8335f5d02c95bd3afc617bcc27c53/de56a/_nuxt/img/f289d3f.jpg");
  background-size: cover;
  background-position: left;
}
@media screen and (max-width: 2000px) {
  section {
    height: 100%;
  }
  .text {
    margin-left: 3rem;
    margin-top: 3rem;
    text-align: center;
  }
}
@media screen and (max-width: 1200px) {
  section {
    height: 100%;
  }
  .text {
    margin-left: 0;
    padding: 0 0.5rem;
    margin: 1rem 0;
  }
  .img {
    height: 100%;
  }
  .first-photo,
  .second-photo,
  .third-photo {
    height: 100%;
  }
}
@media screen and (max-width: 980px) {
  section {
    height: 100%;
    width: 100%;
  }
  .container {
    flex-direction: column;
  }
  .imgs {
    flex-direction: row;
    width: 100%;
    margin-top: 1rem;
  }
  .first-photo,
  .second-photo,
  .third-photo {
    width: 100%;
    height: 5rem;
  }
  .text {
    margin: 0 auto;
    padding: 0;
  }
  .text h2 {
    font-size: 2rem;
    margin-top: 4rem;
  }
  .text p {
    font-size: 1.2rem;
  }
}
@media screen and (max-width: 768px) {
  section {
    height: 100%;
    width: 100%;
  }
  .container {
    flex-direction: column;
  }
  .imgs {
    flex-direction: row;
    width: 100%;
    margin-top: 1rem;
  }
  .first-photo,
  .second-photo,
  .third-photo {
    width: 16rem;
    height: 5rem;
  }
  .text {
    margin: 0 auto;
    padding: 0;
  }
  .text h2 {
    font-size: 2rem;
    margin-top: 4rem;
  }
  .text p {
    font-size: 1.2rem;
  }
  .br {
    display: block;
  }
  .invs {
    display: none;
  }
}
</style>