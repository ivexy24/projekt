<template>
  <section>
    <div class="container">
      <div class="title"><h1>Patrocínio</h1></div>
      <div class="block">
        <a href="#"><img src="../images/Logo-Invilla.jpg" alt="" /></a>
      </div>
      <div class="title2">Organização</div>
      <div class="links">
        <div class="link1">
          <a href="#">
            <img
              src="https://d33wubrfki0l68.cloudfront.net/ea7f491ff17b7ecf8f904201b2e8cefca90771d3/a5533/_nuxt/img/2b1788b.svg"
              alt=""
            />
          </a>
        </div>
        <div class="link2">
          <a href="#">
            <img
              src="https://d33wubrfki0l68.cloudfront.net/2969a022999b5bade58372a646535844b759d0a5/b64c8/_nuxt/img/ce48663.svg"
              alt=""
            />
          </a>
        </div>
      </div>
      <h3>Equipe</h3>
      <div class="team">
        <ul>
          <li>Erick Petrucelli</li>
          <li>Fabio Takeda</li>
          <li>Felipe Espirito Santo</li>
          <li>Gustavo Del Vechio</li>
          <li>Jederson Zuchi</li>
          <li>Luciana Ferrarezi Muzatti</li>
          <li>Oswaldo Lazaro Mendes</li>
          <li>Patricia Primo Lourencano</li>
        </ul>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style scoped>
section {
  height: 70vh;
  width: 100%;
  background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAJCAYAAAALpr0TAAAAR0lEQVQoU2NkQAMREX5SK1ZseoYuzogsAFOETTFcIbokOh+sEFkQF5sRmwQ2MaKsBmnEsBqb50BiKFajBwmy+1GCB5tCmGIAb2NKOq+gGDsAAAAASUVORK5CYII=);
}
.container {
  width: 100%;
  text-align: center;
  padding: 5rem;
}
.title h1 {
  margin-bottom: 3rem;
  color: rgb(red, green, blue);
}
.block {
  margin-bottom: 4rem;
  padding: 1rem;
}
.block img {
  cursor: pointer;
}
.title2 {
  margin-bottom: 3rem;
  font-size: 1.2rem;
}
h3 {
  margin-bottom: 2rem;
}

.block img {
  width: 10rem;
  height: 5rem;
  filter: brightness(500%);
}
.link1,
.link2 {
  padding: 1rem;
  transition: all 0.1s ease;
}
.link1 img,
.link2 img {
  width: 13rem;
}
.link1:hover,
.link2:hover {
  background: rgb(92, 90, 90);
}
.link1:hover img,
.link2:hover img {
  background: grayscale(100%) invert() contrast(0) brightness(500%);
}
.link2 {
  margin-left: 1rem;
}
.links {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 2rem;
}
ul {
  display: flex;
  list-style-type: none;
  align-items: center;
  justify-content: center;
}
li {
  margin: 0 0.75rem;
}
@media screen and (max-width: 2000px) {
  section {
    height: 100%;
  }
}
@media screen and (max-width: 1180px) {
  section {
    height: 100%;
  }
  ul {
    display: inline-block;
    margin: 0 20vw;
  }
  ul li {
    display: inline-block;
    margin: 0.75rem;
  }
}
@media screen and (max-width: 768px) {
  section {
    height: 100%;
  }
  .link1 img,
  .link2 img {
    width: 9rem;
  }
  .team li {
    font-size: 0.7rem;
  }
  ul li {
    display: inline-block;
  }
}
</style>