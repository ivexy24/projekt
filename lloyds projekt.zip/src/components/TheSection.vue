<template>
  <section>
    <div class="container">
      <div class="title"><h1>DevDay</h1></div>
      <div class="date"><h2>9 de novembro de 2019</h2></div>
      <div class="para">
        <h3>
          Um dia dedicado ao desenvolvimento <br />
          web,aplicativos e sistemas em geral
        </h3>
      </div>
    </div>
  </section>
  <section class="section-button">
    <div class="button">
      <button>de sua opiniao</button>
    </div>
  </section>
  <article>
    <div class="parallax">123</div>
  </article>
</template>

<script>
export default {};
</script>

<style scoped>
section {
  height: 75vh;
  width: 100%;
  background: url(../images/red.jpg);
  position: relative;
}

.container {
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.title {
  margin-top: 2.5rem;
  color: #fff;
  font-size: 6rem;
  margin-bottom: 2rem;
}
.date {
  color: #fff;
  font-size: 2rem;
  margin-bottom: 5rem;
}
.para {
  color: #fff;
  font-size: 1.8rem;
}
/*     Section Button     */

.section-button {
  height: 8vh;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  background: rgb(253, 242, 237);
}

button {
  padding: 0.7rem 1.4rem;
  text-transform: uppercase;
  border: none;
  color: #fff;
  background: rgb(224, 4, 4);
  cursor: pointer;
  transition: all 0.12s ease-in;
  font-size: 0.9rem;
}
button:hover {
  color: rgb(224, 4, 4);
  background: #fff;
  border: 2px solid rgb(224, 4, 4);
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
}
.parallax {
  background: url(../images/paral.jpg) 65% 75% / cover fixed;
  min-height: 30vh;
}
.agenda {
  height: 100vh;
  width: 100%;
}
@media screen and (max-width: 568px) {
  .title {
    font-size: 4rem;
    margin-bottom: 2rem;
  }
  .date {
    font-size: 1rem;
  }
  .para {
    font-size: 0.9rem;
  }
  button {
    padding: 0.6rem 1.2rem;
    font-size: 0.8rem;
  }
  .section-button {
    height: 10vh;
  }
  .parallax {
    min-height: 25vh;
  }
}
@media screen and (max-width: 980px) {
  .title {
    font-size: 4rem;
    margin-bottom: 2rem;
  }
  .date {
    font-size: 0.9rem;
  }
  .para {
    font-size: 0.8rem;
  }
  button {
    padding: 0.6rem 1.2rem;
    font-size: 0.8rem;
  }
  .section-button {
    height: 10vh;
  }
  .parallax {
    min-height: 25vh;
  }
}
@media screen and (max-width: 1780px) {
  section {
    height: 90vh;
  }
  .title {
    font-size: 3rem;
  }
  .date {
    font-size: 1.5rem;
  }
  .para {
    font-size: 1.3rem;
  }
  .parallax {
    height: 15vh;
  }
}
</style>
