<template>
  <section>
    <div class="navbar">
      <div class="icon">Icon</div>
      <div class="links">
        <ul>
          <li><a href="#sobre">Sobre</a></li>
          <li><a href="#agenda">Agenda</a></li>
          <li><a href="#local">Local</a></li>
        </ul>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style scoped>
section {
  height: 2.5rem;
  width: 100%;
  box-shadow: 0px 5px 8px rgba(0, 0, 0, 0.2);
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 121;
  background: #fff;
}
.navbar {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  border-bottom: 1px solid black;
  overflow: hidden;
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12),
    0 3px 1px -2px rgba(0, 0, 0, 0.2);
}
.icon {
  cursor: pointer;
  padding: 1rem;
}

.links ul {
  list-style-type: none;
  margin-left: 2rem;
  display: flex;
  justify-content: center;
  align-items: center;
}
.links li {
  padding: 1rem;
  cursor: pointer;
  transition: all 0.2s ease;
}
.links li:hover {
  background: rgb(223, 4, 4);
}
.links li:hover a {
  color: #fff;
}

.links li a {
  text-decoration: none;
  color: rgb(219, 8, 8);
  text-transform: capitalize;
  font-weight: bold;
  font-size: 15px;
}
a:link,
a:active {
  color: rgb(219, 8, 8);
}
@media screen and (max-width: 2000px) {
  .links li a {
    font-size: 1rem;
  }
  section {
    height: 3rem;
  }
}
@media screen and (max-width: 1200px) {
  .links li a {
    font-size: 1.1rem;
  }
  section {
    height: 3rem;
  }
}
@media screen and (max-width: 980px) {
  section {
    height: 2.5rem;
  }
  .links li a {
    font-size: 0.9rem;
  }
}
@media screen and (max-width: 568px) {
  section {
    height: 2rem;
  }
  .links li a {
    font-size: 0.7rem;
  }
  .icon {
    font-size: 0.9rem;
  }
}
</style>