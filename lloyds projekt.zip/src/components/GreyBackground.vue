<template>
  <div class="grey"></div>
</template>

<script>
export default {};
</script>

<style scoped>
.grey {
  height: 2rem;
  width: 100%;
  background: rgb(58, 58, 58);
}
</style>