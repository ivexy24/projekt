<template>
  <section>
    <div class="container">
      <div class="icon-img">Image</div>
      <p>
        © 2019 <a href="#"> Fatec Taquaritinga</a><br />
        Todos os direitos reservados
      </p>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style scoped>
section {
  height: 20vh;
  text-align: center;
  position: relative;
  background: #c6d1d6;
}
.container {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
a {
  color: black;
  text-decoration: none;
  cursor: pointer;
}
a:hover {
  color: red;
}
p {
  color: rgba(60, 76, 83, 0.67);
}
.icon-img {
  margin-bottom: 2rem;
}

@media screen and (max-width: 568px) {
  p {
    font-size: 0.8rem;
  }
}
@media screen and (max-width: 1780px) {
  p {
    font-size: 0.9rem;
  }
}
</style>