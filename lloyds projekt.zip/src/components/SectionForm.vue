<template>
  <section>
    <div class="text">
      <h2>Participiou conosco?</h2>
      <p>O que você achou do Fatec Dev Day 2019?</p>
    </div>
    <a href="#"> de sua opiniao </a>
  </section>
</template>

<script>
export default {};
</script>

<style scoped>
section {
  background: radial-gradient(#fff, #f2f1ec);
  min-height: 40vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12),
    0 3px 1px -2px rgba(0, 0, 0, 0.2);
}
h2 {
  color: red;
  font-size: 1rem;
}
p {
  font-size: 0.8rem;
  margin-top: 0.1rem;
}
.text {
  margin-bottom: 2rem;
  text-align: center;
}
a {
  padding: 0.7rem 1.4rem;
  text-transform: uppercase;
  border: none;
  color: #fff;
  background: rgb(224, 4, 4);
  cursor: pointer;
  transition: all 0.12s ease-in;
  font-size: 0.9rem;
  text-decoration: none;
}

a:hover {
  color: rgb(224, 4, 4);
  background: #fff;
  border: 2px solid rgb(224, 4, 4);
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
}
</style>