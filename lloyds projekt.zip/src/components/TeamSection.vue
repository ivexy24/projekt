<template>
  <section>
    <div class="text">
      <div class="title">
        <h2 id="leo">Palestrantes</h2>
      </div>
      <div class="para">
        <p>
          Palestrantes escolhidos por suas experiências profissionais e seus
          conhecimentos destacados nos temas respectivos. Este é um evento
          multi-linguagem, não focando em apenas um ecossistema de programação,
          mas em diferentes técnicas e tecnologias que estão emergindo ou
          ganhando maior destaque no mercado.
        </p>
      </div>
    </div>
    <div class="cards">
      <div class="member-cont">
        <div class="img-cont">
          <img src="../images/member1.jpg" alt="Member1" />
        </div>
        <div class="memb-title">
          <h2 id="bruno">Bruno Schaefer</h2>
        </div>
        <p>Software Engineer</p>
        <a href="#">Nubank</a>
        <div class="flex-cont">
          <div class="soc-icons">
            <i class="fas fa-linkedin">fafa</i>
          </div>
          <button>Saiba Mais</button>
        </div>
      </div>
      <div class="member-cont">
        <div class="img-cont">
          <img src="../images/member3.jpg" alt="Member1" />
        </div>
        <div class="memb-title">
          <h2>Cleber Campomori</h2>
        </div>
        <p>Engenheiro de Software</p>
        <a href="#">MovilePay</a>
        <div class="flex-cont">
          <div class="soc-icons">
            <i class="fas fa-linkedin">fafa</i>
          </div>
          <button>Saiba Mais</button>
        </div>
      </div>
      <div class="member-cont">
        <div class="img-cont">
          <img src="../images/member4.jpg" alt="Member1" />
        </div>
        <div class="memb-title">
          <h2>Hugo Branquinho</h2>
        </div>
        <p>Sênior SRE</p>
        <a href="#">iFood</a>
        <div class="flex-cont">
          <div class="soc-icons">
            <i class="fas fa-linkedin">fafa</i>
          </div>
          <button>Saiba Mais</button>
        </div>
      </div>
      <div class="member-cont">
        <div class="img-cont">
          <img src="../images/member5.jpg" alt="Member1" />
        </div>
        <div class="memb-title">
          <h2>Leonardo Bittencourt</h2>
        </div>
        <p>Software Engineer</p>
        <a href="#">Conexia Educação</a>
        <div class="flex-cont">
          <div class="soc-icons">
            <i class="fas fa-linkedin">fafa</i>
          </div>
          <button>Saiba Mais</button>
        </div>
      </div>
      <div class="member-cont">
        <div class="img-cont">
          <img src="../images/member5.jpg" alt="Member1" />
        </div>
        <div class="memb-title">
          <h2>Leonardo Bittencourt</h2>
        </div>
        <p>Software Engineer</p>
        <a href="#">Conexia Educação</a>
        <div class="flex-cont">
          <div class="soc-icons">
            <i class="fas fa-linkedin">fafa</i>
          </div>
          <button>Saiba Mais</button>
        </div>
      </div>
      <div class="member-cont">
        <div class="img-cont">
          <img src="../images/member5.jpg" alt="Member1" />
        </div>
        <div class="memb-title">
          <h2>Leonardo Bittencourt</h2>
        </div>
        <p>Software Engineer</p>
        <a href="#">Conexia Educação</a>
        <div class="flex-cont">
          <div class="soc-icons">
            <i class="fas fa-linkedin">fafa</i>
          </div>
          <button>Saiba Mais</button>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style scoped>
section {
  height: 100%;
  background: #c6d1d6;
  padding: 4rem 10rem;
}
img {
  border-radius: 50%;
  height: 12.5rem;
  width: 12.5rem;
  /* border: 15px solid rgba(203, 212, 216); */
  overflow: hidden;
  /* transform: translateY(-25%); */
  transition: all 0.1s;
  cursor: pointer;
  object-fit: cover;
}
.img-cont:hover img {
  transform: scale(1.09) translateX(-0.7rem);
}
.img-cont:hover {
  border: 15px solid rgb(228, 228, 228);
}
.para p {
  color: rgba(60, 76, 83, 0.97);
  font-size: 1.1rem;
  font-weight: bold;
}

.flex-cont {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 0.5rem;
}
.text {
  text-align: center;
  margin-bottom: 5rem;
}

.title {
  color: red;
  font-size: 1.5rem;
  margin-bottom: 0.7rem;
}
.member-cont {
  width: 22rem;
  height: 20rem;
  background: #fff;
  text-align: center;
  position: relative;
  margin-bottom: 2rem;
}
.img-cont {
  border-radius: 50%;
  height: 14rem;
  width: 14rem;
  border: 15px solid #c6d1d6;
  overflow: hidden;
  transform: translateY(-30%) translateX(30%);
  transition: all 0.2s ease;
  display: flex;
  justify-content: center;
  align-items: center;
}
.memb-title {
  margin-top: -2rem;
  font-weight: bold;
  color: red;
}
p {
  margin: 0.1rem 0;
  color: rgb(163, 172, 175);
  font-size: 0.8rem;
}
a {
  color: black;
  font-size: 0.8rem;
}
button {
  padding: 0.5rem 1.5rem;
  margin-left: 1rem;
  border: none;
  background: #fff;
  border: 3px solid #c6d1d6;
  cursor: pointer;
  transition: all 0.1s;
}
button:hover {
  background: #c6d1d6;
}
.cards {
  display: flex;
  justify-content: center;
  flex-flow: row wrap;
  gap: 3rem;
}
@media screen and (max-width: 1180px) {
  .member-cont {
    flex-basis: 320px;
    max-width: 380px;
    margin: 3rem 0;
  }
  .img-cont {
    width: 13rem;
    height: 13rem;
    transform: translatey(-40%) translateX(26%);
  }
}
@media screen and (max-width: 680px) {
  .member-cont {
    max-width: 360px;
    height: 16rem;
    margin-bottom: 4rem;
  }
  .img-cont {
    transform: translateY(-40%) translateX(50%);
    height: 10rem;
    width: 10rem;
  }
}
@media screen and (max-width: 568px) {
  section {
    padding: 1rem 4rem;
  }
  .member-cont {
    width: 16rem;
    height: 18rem;
    margin-bottom: 8rem;
  }
  .img-cont {
    transform: translateY(-40%) translateX(50%);
    height: 10rem;
    width: 10rem;
  }
  /* .img-cont img {
    height: 10rem;
    width: 10rem;
    transform: translateX(-0.7rem);
  } */
}
@media screen and (max-width: 400px) {
  .img-cont {
    width: 9rem;
    height: 9rem;
    transform: translateY(-40%) translateX(37%);
  }
  .memb-title {
    padding: 0.1rem 0.2rem;
  }
}
</style>