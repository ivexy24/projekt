import { createApp } from 'vue'
import App from './App.vue'





import TheNavbar from './components/TheNavbar.vue'


const app = createApp(App)




app.component('the-navbar', TheNavbar)


app.mount('#app')
